process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
const { Client } = require('pg');
require('dotenv').config();

const connectionString = process.env.DATABASE_URL;
console.log('Attempting to connect with URL (masked password):', connectionString.replace(/:[^:@]+@/, ':****@'));

const client = new Client({
  connectionString: connectionString,
});

async function test() {
  try {
    await client.connect();
    console.log('SUCCESS: Connected to the database!');
    const res = await client.query('SELECT current_database(), current_user, version();');
    console.log('DATABASE INFO:', res.rows[0]);
    
    // Check if the Profile table exists
    const tableRes = await client.query("SELECT count(*) FROM information_schema.tables WHERE table_schema = 'public' AND table_name = 'Profile';");
    console.log('Profile table exists?', tableRes.rows[0].count === '1' ? 'YES' : 'NO');
    
    await client.end();
  } catch (err) {
    console.error('ERROR connecting to the database:', err.message);
    process.exit(1);
  }
}

test();
