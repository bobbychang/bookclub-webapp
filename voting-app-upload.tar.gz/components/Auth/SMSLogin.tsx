'use client';
import { useState } from 'react';
import { createClient } from '@/utils/supabase/client';

export default function SMSLogin({ onLoginSuccess }: { onLoginSuccess: () => void }) {
  const [phoneNumber, setPhoneNumber] = useState('');
  const [otp, setOtp] = useState('');
  const [step, setStep] = useState<'phone' | 'otp'>('phone');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const supabase = createClient();
  const isDevMode = process.env.NEXT_PUBLIC_DEV_MODE === 'true';

  const handleSendOTP = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Dev Mode Shortcuts
    if (isDevMode) {
        if (phoneNumber === '123') {
            handleDevLogin('+15102198730', 'dev-admin-id');
            return;
        }
        if (phoneNumber === '456') {
            handleDevLogin('+19998887777', 'dev-user-id-1');
            return;
        }
        // Allow any 3-digit number as a unique dev user
        if (phoneNumber.length === 3) {
            handleDevLogin(`+10000000${phoneNumber}`, `dev-user-${phoneNumber}`);
            return;
        }
    }

    setLoading(true);
    setError(null);

    const formattedPhone = phoneNumber.startsWith('+') ? phoneNumber : `+1${phoneNumber.replace(/\D/g, '')}`;

    const { error } = await supabase.auth.signInWithOtp({
      phone: formattedPhone,
    });

    if (error) {
      setError(error.message);
    } else {
      setStep('otp');
    }
    setLoading(false);
  };

  const handleVerifyOTP = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const formattedPhone = phoneNumber.startsWith('+') ? phoneNumber : `+1${phoneNumber.replace(/\D/g, '')}`;

    const { error } = await supabase.auth.verifyOtp({
      phone: formattedPhone,
      token: otp,
      type: 'sms',
    });

    if (error) {
      setError(error.message);
    } else {
      onLoginSuccess();
    }
    setLoading(false);
  };

  const handleDevLogin = (phone: string, id: string) => {
    const devUser = {
        id: id,
        phone: phone,
        isDev: true
    };
    localStorage.setItem('dev-session', JSON.stringify(devUser));
    onLoginSuccess();
  };

  return (
    <div className="p-6 border-2 border-gray-100 rounded-3xl bg-white shadow-xl space-y-4 max-w-sm mx-auto mt-20">
      <h2 className="text-2xl font-bold text-gray-800 text-center">
        {step === 'phone' ? 'Welcome!' : 'Verify OTP'}
      </h2>
      
      {isDevMode && (
        <div className="bg-yellow-50 border border-yellow-200 p-3 rounded-xl text-center space-y-2">
            <p className="text-yellow-700 text-[10px] font-bold uppercase tracking-widest">Dev Mode Shortcuts</p>
            <div className="flex flex-wrap gap-2 justify-center">
                <button 
                    onClick={() => handleDevLogin('+15102198730', 'dev-admin-id')}
                    className="text-[10px] bg-yellow-500 hover:bg-yellow-600 text-white font-bold py-1 px-3 rounded-lg transition-colors"
                >
                    Login as Admin
                </button>
                <button 
                    onClick={() => handleDevLogin('+19990001111', 'dev-user-id-1')}
                    className="text-[10px] bg-blue-500 hover:bg-blue-600 text-white font-bold py-1 px-3 rounded-lg transition-colors"
                >
                    Login as User A
                </button>
                <button 
                    onClick={() => handleDevLogin('+19990002222', 'dev-user-id-2')}
                    className="text-[10px] bg-purple-500 hover:bg-purple-600 text-white font-bold py-1 px-3 rounded-lg transition-colors"
                >
                    Login as User B
                </button>
            </div>
            <p className="text-[10px] text-yellow-600 italic">Tip: Type any 3 digits in the phone field to login as a unique user.</p>
        </div>
      )}

      <p className="text-gray-500 text-sm text-center">
        {step === 'phone' 
          ? 'Enter your phone number to sign in.' 
          : `Enter the code sent to ${phoneNumber}.`}
      </p>

      {error && <p className="text-red-500 text-xs text-center">{error}</p>}

      {step === 'phone' ? (
        <form onSubmit={handleSendOTP} className="space-y-4">
          <input
            type="tel"
            placeholder="Phone Number"
            className="border-2 border-gray-200 p-3 w-full rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
            value={phoneNumber}
            onChange={(e) => setPhoneNumber(e.target.value)}
            required
          />
          <button
            type="submit"
            disabled={loading}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-xl shadow-lg transform active:scale-95 transition-all disabled:opacity-50"
          >
            {loading ? 'Sending...' : 'Send Code'}
          </button>
        </form>
      ) : (
        <form onSubmit={handleVerifyOTP} className="space-y-4">
          <input
            type="text"
            placeholder="6-digit OTP"
            className="border-2 border-gray-200 p-3 w-full rounded-xl text-center text-2xl tracking-widest focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
            value={otp}
            onChange={(e) => setOtp(e.target.value)}
            maxLength={6}
            required
          />
          <button
            type="submit"
            disabled={loading}
            className="w-full bg-black hover:bg-gray-800 text-white font-bold py-3 rounded-xl shadow-lg transform active:scale-95 transition-all disabled:opacity-50"
          >
            {loading ? 'Verifying...' : 'Login'}
          </button>
        </form>
      )}
    </div>
  );
}
