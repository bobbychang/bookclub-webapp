'use client';
import { useState } from 'react';
import { createClient } from '@/utils/supabase/client';

export default function ProfileSetup({ onComplete }: { onComplete: () => void }) {
  const [displayName, setDisplayName] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const supabase = createClient();
  const isDevMode = process.env.NEXT_PUBLIC_DEV_MODE === 'true';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    let user: any = null;

    // Check for real Supabase user first
    const { data: { user: supabaseUser } } = await supabase.auth.getUser();
    user = supabaseUser;

    // If no real user and in dev mode, check for dev session
    if (!user && isDevMode) {
        const devSessionStr = localStorage.getItem('dev-session');
        if (devSessionStr) {
            user = JSON.parse(devSessionStr);
        }
    }

    if (!user) {
      setError('No user found. Please try logging in again.');
      setLoading(false);
      return;
    }

    // Administrator account is tied to 15102198730
    const isAdmin = user.phone === '+15102198730';
    const now = new Date().toISOString();

    const { error: upsertError } = await supabase
      .from('Profile')
      .upsert({
        id: user.id,
        phoneNumber: user.phone!,
        displayName: displayName,
        isAdmin: isAdmin,
        updatedAt: now, // Manually provide as we are using Supabase client bypass
        createdAt: now,
      }, { onConflict: 'phoneNumber' });

    if (upsertError) {
      setError(upsertError.message);
    } else {
      onComplete();
    }
    setLoading(false);
  };

  return (
    <div className="p-6 border-2 border-gray-100 rounded-3xl bg-white shadow-xl space-y-4 max-w-sm mx-auto mt-20">
      <h2 className="text-2xl font-bold text-gray-800 text-center">Complete Your Profile</h2>
      <p className="text-gray-500 text-sm text-center">Please choose a display name so others know who you are.</p>

      {error && <p className="text-red-500 text-xs text-center">{error}</p>}

      <form onSubmit={handleSubmit} className="space-y-4">
        <input
          type="text"
          placeholder="Display Name (e.g. Bobby)"
          className="border-2 border-gray-200 p-3 w-full rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
          value={displayName}
          onChange={(e) => setDisplayName(e.target.value)}
          required
        />
        <button
          type="submit"
          disabled={loading}
          className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-xl shadow-lg transform active:scale-95 transition-all disabled:opacity-50"
        >
          {loading ? 'Saving...' : 'Finish Setup'}
        </button>
      </form>
    </div>
  );
}
